package com.dentalmanagement.DentalManagement.Service;

public class Authentication {

}
