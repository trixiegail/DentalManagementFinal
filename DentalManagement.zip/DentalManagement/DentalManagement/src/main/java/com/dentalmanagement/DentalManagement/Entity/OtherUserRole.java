package com.dentalmanagement.DentalManagement.Entity;

public enum OtherUserRole {
	ADMIN,
	NURSE,
	DOCTOR,
	STAFF
}
